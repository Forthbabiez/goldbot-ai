# GoldBot AI — iPhone starter

This is a browser-hosted educational simulator. It uses randomly generated sample candles and does not connect to a broker, receive live quotes, or place trades.

## Deploy from an iPhone

1. Download and unzip this project.
2. In Safari, sign in to GitHub and create a new public repository named `goldbot-ai`.
3. Upload `app.py` and `requirements.txt` to the repository root.
4. Open https://share.streamlit.io/ and sign in with GitHub.
5. Choose **Create app**, select your `goldbot-ai` repository, branch `main`, and main file `app.py`.
6. Deploy. Open the generated app URL in Safari.

## Notes
- This app is a learning prototype, not financial advice.
- Candles are synthetic and are not XAUUSD market prices.
- The backtest is deliberately simplified and omits spread, slippage, swaps, commissions and realistic position sizing.
- Do not use the displayed results to make real-money decisions.
